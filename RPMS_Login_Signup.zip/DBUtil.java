
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:rpms.db");
    }

    public static void initialize() {
        try (Connection conn = connect()) {
            var stmt = conn.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                         "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                         "name TEXT NOT NULL, " +
                         "email TEXT UNIQUE NOT NULL, " +
                         "password TEXT NOT NULL, " +
                         "role TEXT NOT NULL)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
