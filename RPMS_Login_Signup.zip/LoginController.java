
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.sql.*;

public class LoginController {
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private ComboBox<String> roleBox;
    @FXML private Label statusLabel;

    @FXML
    public void initialize() {
        roleBox.getItems().addAll("Doctor", "Patient", "Admin");
    }

    @FXML
    private void login() {
        String email = emailField.getText();
        String pass = passwordField.getText();
        String role = roleBox.getValue();

        try (Connection conn = DBUtil.connect()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE email=? AND password=? AND role=?");
            ps.setString(1, email);
            ps.setString(2, pass);
            ps.setString(3, role);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                loadDashboard(role);
            } else {
                statusLabel.setText("Invalid credentials.");
            }
        } catch (SQLException | Exception e) {
            e.printStackTrace();
        }
    }

    private void loadDashboard(String role) throws Exception {
        Stage stage = (Stage) emailField.getScene().getWindow();
        FXMLLoader loader = switch (role) {
            case "Doctor" -> new FXMLLoader(getClass().getResource("doctor.fxml"));
            case "Patient" -> new FXMLLoader(getClass().getResource("patient.fxml"));
            case "Admin" -> new FXMLLoader(getClass().getResource("admin.fxml"));
            default -> throw new IllegalStateException("Unknown role");
        };
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
    }

    @FXML
    private void goToSignup() throws Exception {
        Stage stage = (Stage) emailField.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("signup.fxml"))));
    }
}
