
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.sql.*;

public class SignupController {
    @FXML private TextField nameField, emailField;
    @FXML private PasswordField passwordField;
    @FXML private ComboBox<String> roleBox;
    @FXML private Label statusLabel;

    @FXML
    public void initialize() {
        roleBox.getItems().addAll("Doctor", "Patient", "Admin");
    }

    @FXML
    private void signup() {
        try (Connection conn = DBUtil.connect()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users(name, email, password, role) VALUES (?, ?, ?, ?)");
            ps.setString(1, nameField.getText());
            ps.setString(2, emailField.getText());
            ps.setString(3, passwordField.getText());
            ps.setString(4, roleBox.getValue());
            ps.executeUpdate();
            statusLabel.setText("Signup successful! You can now log in.");
        } catch (SQLException e) {
            if (e.getMessage().contains("UNIQUE")) {
                statusLabel.setText("Email already registered.");
            } else {
                statusLabel.setText("Error signing up.");
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void goToLogin() throws Exception {
        Stage stage = (Stage) emailField.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("login.fxml"))));
    }
}
