/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rpms;
import java.util.*;
import java.awt.Desktop;
import java.net.URI;
import java.util.Scanner;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.MessagingException;

interface Notifiable {
    void sendNotification(String message);
}
   
    class EmailNotification implements Notifiable {
    private String recipientEmail;

    private final String senderEmail = "fatimaahmed04478@gmail.com";
    private final String senderPassword = "ivkl yguc zxjg urxo"; 

    public EmailNotification(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    @Override
    public void sendNotification(String messageText) {
        String subject = "Health System Notification";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(
                    Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(messageText);

            Transport.send(message);
            System.out.println("Email sent to " + recipientEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println(" Failed to send email.");
        }
    }
}

class SMSNotification implements Notifiable {
    private String phoneNumber;

    public SMSNotification(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public void sendNotification(String message) {
        System.out.println("SMS sent to " + phoneNumber + ": " + message);
    }
}

class NotificationService {
    private List<Notifiable> channels;

    public NotificationService() {
        this.channels = new ArrayList<>();
    }

    public void addChannel(Notifiable channel) {
        channels.add(channel);
    }

    public void sendAlert(String message) {
        for (Notifiable channel : channels) {
            channel.sendNotification(message);
        }
    }
}

class EmergencyAlert {
    private double heartRate, oxygenLevel, temperature;
    private NotificationService notificationService;

    public EmergencyAlert(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    public void updateVitals(double heartRate, double oxygenLevel, double temperature) {
        this.heartRate = heartRate;
        this.oxygenLevel = oxygenLevel;
        this.temperature = temperature;
        checkVitals();
    }

    private void checkVitals() {
        if (heartRate > 120 || oxygenLevel < 90 || temperature > 102) {
            notificationService.sendAlert("CRITICAL ALERT: Patient vitals are abnormal!");
        } else {
            System.out.println("Vitals are within normal range.");
        }
    }
}

class PanicButton {
    private NotificationService notificationService;

    public PanicButton(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    public void press() {
        notificationService.sendAlert("EMERGENCY: Panic button was pressed!");
    }
}

class ChatServer {
    private List<String> chatHistory = new ArrayList<>();

    public void receiveMessage(String sender, String message) {
    String fullMessage = sender + ": " + message;
    chatHistory.add(fullMessage);
}


    public List<String> getChatHistory() {
        return chatHistory;
    }
}

class ChatClient {
    private String userName;
    private ChatServer server;

    public ChatClient(String userName, ChatServer server) {
        this.userName = userName;
        this.server = server;
    }

    public void sendMessage(String message) {
        server.receiveMessage(userName, message);
    }

    public void readMessages() {
        System.out.println("Chat history for " + userName + ":");
        for (String msg : server.getChatHistory()) {
            System.out.println(msg);
        }
    }
}

// ----- Video Call -----
class VideoCall {
    private String link;

    public VideoCall(String link) {
        this.link = link;
    }

    public void startCall() {
        try {
            Desktop.getDesktop().browse(new URI(link));
            System.out.println("Opening video consultation link: " + link);
        } catch (Exception e) {
            System.out.println("Failed to start video call: " + e.getMessage());
        }
    }
}

class ReminderService {
    private List<Notifiable> channels = new ArrayList<>();

    public void addReminderChannel(Notifiable channel) {
        channels.add(channel);
    }

    public void sendAppointmentReminder(String appointmentDetails) {
        for (Notifiable channel : channels) {
            channel.sendNotification("Appointment Reminder: " + appointmentDetails);
        }
    }

    public void sendMedicationReminder(String medicationDetails) {
        for (Notifiable channel : channels) {
            channel.sendNotification("Medication Reminder: " + medicationDetails);
        }
    }
}


public class RPMS {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter Doctor's Email: ");
        String doctorEmail = scanner.nextLine();

        String patientEmail = "fatimaahmed04478@gmail.com";

        NotificationService notifier = new NotificationService();
        notifier.addChannel(new EmailNotification(doctorEmail));
        notifier.addChannel(new SMSNotification("+1234567890"));

        EmergencyAlert alert = new EmergencyAlert(notifier);
        PanicButton panic = new PanicButton(notifier);
        ChatServer chatServer = new ChatServer();
        ChatClient doctor = new ChatClient("Dr. Nazia", chatServer);
        ChatClient patient = new ChatClient("Patient Sara", chatServer);
        VideoCall videoCall = new VideoCall("https://zoom.us/my/consultation123");
        ReminderService reminderService = new ReminderService();
        reminderService.addReminderChannel(new EmailNotification(patientEmail));
        reminderService.addReminderChannel(new SMSNotification("+9876543210"));

        boolean running = true;

        while (running) {
            System.out.println("\n=== Remote Health Monitoring System ===");
            System.out.println("1. Chat with Doctor");
            System.out.println("2. Start Video Consultation");
            System.out.println("3. Send Email to Doctor");
            System.out.println("4. Trigger Emergency Alert");
            System.out.println("5. Press Panic Button");
            System.out.println("6. Send Appointment Reminder");
            System.out.println("7. Send Medication Reminder");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
              
            case 1:
            System.out.print("Are you a Doctor or Patient? (D/P): ");
            String role = scanner.nextLine().trim().toUpperCase();
            String userName;

            if (role.equals("D")) {
            System.out.print("Enter Doctor Name: ");
            userName = scanner.nextLine();
            } else if (role.equals("P")) {
            System.out.print("Enter Patient Name: ");
            userName = scanner.nextLine();
            } else {
            System.out.println("Invalid role. Returning to main menu.");
            break;
            }

            ChatClient chatUser = new ChatClient(userName, chatServer);
            System.out.print(userName + ": ");
            String message = scanner.nextLine();
            chatUser.sendMessage(message);
  
            System.out.println("\n--- Chat History ---");
            chatUser.readMessages();
            break;


                case 2:
                    videoCall.startCall();
                    break;
                case 3:
                    System.out.print("Enter recipient's email address: ");
                    String recipient = scanner.nextLine();

                    System.out.print("Enter your message: ");
                    String emailMsg = scanner.nextLine();

                    Notifiable dynamicEmail = new EmailNotification(recipient);
                    dynamicEmail.sendNotification(emailMsg);
                    break;

                case 4:
                    System.out.println("Enter vitals to check:");
                    System.out.print("Heart Rate: ");
                    double hr = scanner.nextDouble();
                    System.out.print("Oxygen Level: ");
                    double ox = scanner.nextDouble();
                    System.out.print("Temperature: ");
                    double temp = scanner.nextDouble();
                    alert.updateVitals(hr, ox, temp);
                    break;
                case 5:
                    panic.press();
                    break;
                case 6:
                    reminderService.sendAppointmentReminder("Checkup with Dr. Ahmed on Monday at 10 AM.");
                    break;
                case 7:
                    reminderService.sendMedicationReminder("Take Paracetamol at 9:00 AM.");
                    break;
                case 8:
                    System.out.println("Exiting system. Stay healthy!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}